# my_project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth.views import LogoutView
from inventory import views  # Importar las vistas de inventory

urlpatterns = [
    path('admin/', admin.site.urls),
    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
    path('', views.home, name='home'),  # Usar la vista home de inventory
    path('services/', views.services, name='services'),  # 
    path('account/', views.account, name='account'),  
    path('contact/', views.contact, name='contact'),   
    path('plans/', views.plans, name='plans'),  
    path('history/', views.history, name='history'),  
    path('register/', views.register, name='register'),  # 
    path('usser/', views.usser, name='usser'),  #
    path('l_solicitud/', views.l_solicitud, name='l_solicitud'),  # 
    path('p_solicitud/', views.p_solicitud, name='p_solicitud'),  #
    path('nuev_solici/', views.nuev_solici, name='nuev_solici'),  #
    path('solicitud/', views.solicitud, name='solicitud'),
    path('solicitud_exitosa/', views.solicitud_exitosa, name='solicitud_exitosa'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('register/', views.register, name='register'),
    path('success/', views.success, name='success'),
    path('', include('inventory.urls')),
]
