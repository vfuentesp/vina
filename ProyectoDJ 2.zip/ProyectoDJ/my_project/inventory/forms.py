# inventory/forms.py
from django import forms
from .models import Medicamento
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser


class SolicitudForm(forms.Form):
    medicamento = forms.ModelChoiceField(queryset=Medicamento.objects.all(), label="Medicamento")
    cantidad = forms.IntegerField(label="Cantidad")
    comentario = forms.CharField(widget=forms.Textarea, label="Comentario", required=False)
    
class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    email = forms.EmailField(required=True)
    dob = forms.DateField(required=True)
    institution = forms.CharField(max_length=255, required=True)
    phone_number = forms.CharField(max_length=9, required=True)

    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'dob', 'institution', 'phone_number', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user