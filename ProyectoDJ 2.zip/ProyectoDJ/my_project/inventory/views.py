# inventory/views.py
from django.shortcuts import render, redirect
from .forms import SolicitudForm  # Importar el formulario
from .models import Medicamento
from .models import Solicitud
from django.contrib.auth import login, authenticate
from .forms import CustomUserCreationForm
from django.contrib import messages

def home(request):
    return render(request, 'home.html')

def services(request):
    return render(request, 'services.html')

def account(request):
    return render(request, 'account.html')

def contact(request):
    return render(request, 'contact.html')

def plans(request):
    return render(request, 'plans.html')

def history(request):
    return render(request, 'history.html')

def register(request):
    return render(request, 'register.html')

def usser(request):
    return render(request, 'usser.html')

def l_solicitud(request):
    return render(request, 'l_solicitud.html')

def p_solicitud(request):
    return render(request, 'p_solicitud.html')

def nuev_solici(request):
    return render(request, 'nuev_solici.html')

def success(request):
    return render(request, 'success.html')

def solicitud(request):
    if request.method == 'POST':
        form = SolicitudForm(request.POST)
        if form.is_valid():
            # Procesar los datos del formulario y guardar la solicitud
            medicamento = form.cleaned_data['medicamento']
            cantidad = form.cleaned_data['cantidad']
            comentario = form.cleaned_data['comentario']
            # Aquí podrías guardar la solicitud en la base de datos si tienes un modelo para solicitudes
            # solicitud = Solicitud(medicamento=medicamento, cantidad=cantidad, comentario=comentario)
            # solicitud.save()
            return redirect('solicitud_exitosa')  # Redirige a una página de éxito
    else:
        form = SolicitudForm()
    
    return render(request, 'solicitud.html', {'form': form})

def solicitud_exitosa(request):
    return render(request, 'solicitud_exitosa.html')

def usser(request):
    nuevas_solicitudes = Solicitud.objects.filter(estado='nueva')
    listas_solicitudes = Solicitud.objects.filter(estado='lista')
    pendientes_solicitudes = Solicitud.objects.filter(estado='pendiente')
    
    context = {
        'nuevas_solicitudes': nuevas_solicitudes,
        'listas_solicitudes': listas_solicitudes,
        'pendientes_solicitudes': pendientes_solicitudes,
    }
    
    return render(request, 'usser.html', context)

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('account')  # Cambia 'home' a la URL a la que deseas redirigir después del registro
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})

def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registro exitoso. ¡Bienvenido!')
            return redirect('success')  # Redirige a la página de éxito
        else:
            messages.error(request, 'Por favor corrige los errores abajo.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})