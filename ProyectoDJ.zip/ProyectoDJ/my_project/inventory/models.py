from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    pass

class Medicamento(models.Model):
    name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField()

    def __str__(self):
        return self.name

class Solicitud(models.Model):
    ESTADO_CHOICES = [
        ('nueva', 'Nueva'),
        ('lista', 'Lista'),
        ('pendiente', 'Pendiente')
    ]
    medicamento = models.CharField(max_length=255)
    cantidad = models.IntegerField()
    comentario = models.TextField()
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='nueva')

    def __str__(self):
        return f"{self.medicamento} - {self.cantidad} - {self.estado}"
