from pyexpat.errors import messages
from django.shortcuts import render, redirect # type: ignore
from django.contrib.auth.decorators import login_required, permission_required
from my_project.inventory.forms import CustomUserCreationForm
from my_project.inventory.models import Medicamento  # Cambiado de .models a models

def home(request):
    return render(request, 'home.html')


def services(request):
    return render(request, 'services.html')

def account(request):
    return render(request, 'account.html')

def contact(request):
    return render(request, 'contact.html')

def plans(request):
    return render(request, 'plans.html')

def history(request):
    return render(request, 'history.html')

def l_solicitud(request):
    return render(request, 'l_solicitud.html')

def p_solicitud(request):
    return render(request, 'p_solicitud.html')

def nuev_solici(request):
    return render(request, 'nuev_solici.html')

def solicitud(request):
    return render(request, 'solicitud.html')

def register(request):
    return render(request, 'register.html')

def usser(request):
    return render(request, 'usser.html')

def success(request):
    return render(request, 'success.html')


@login_required
@permission_required('app_name.can_manage_stock', raise_exception=True)
def manage_stock(request):
    medicamentos = Medicamento.objects.all()
    return render(request, 'manage_stock.html', {'medicamentos': medicamentos})

@login_required
@permission_required('app_name.can_manage_stock', raise_exception=True)
def add_medicamento(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        quantity = request.POST.get('quantity')
        Medicamento.objects.create(name=name, quantity=quantity)
        return redirect('manage_stock')
    return render(request, 'add_medicamento.html')

@login_required
@permission_required('app_name.can_manage_stock', raise_exception=True)
def edit_medicamento(request, id):
    medicamento = Medicamento.objects.get(id=id)
    if request.method == 'POST':
        medicamento.name = request.POST.get('name')
        medicamento.quantity = request.POST.get('quantity')
        medicamento.save()
        return redirect('manage_stock')
    return render(request, 'edit_medicamento.html', {'medicamento': medicamento})

@login_required
@permission_required('app_name.can_manage_stock', raise_exception=True)
def delete_medicamento(request, id):
    medicamento = Medicamento.objects.get(id=id)
    if request.method == 'POST':
        medicamento.delete()
        return redirect('manage_stock')
    return render(request, 'delete_medicamento.html', {'medicamento': medicamento})

def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user) # type: ignore
            messages.success(request, 'Registro exitoso. ¡Bienvenido!')
            return redirect('success')  # Redirige a la página de éxito
        else:
            messages.error(request, 'Por favor corrige los errores abajo.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})
